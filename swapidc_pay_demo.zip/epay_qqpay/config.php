<?php
return array(
	'plug' => 'epay_qqpay',
	'name' => '乐乐支付-QQ钱包',
	'version' => '7.0',
);
?>