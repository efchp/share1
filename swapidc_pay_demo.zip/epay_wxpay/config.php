<?php
return array(
	'plug' => 'epay_wxpay',
	'name' => '乐乐支付-微信钱包',
	'version' => '7.0',
);
?>