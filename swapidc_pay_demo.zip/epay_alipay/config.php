﻿<?php
return array(
	'plug' => 'epay_alipay',
	'name' => '乐乐支付-支付宝',
	'version' => '7.0',
);
?>