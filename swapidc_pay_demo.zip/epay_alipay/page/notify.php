<?php
$OSWAP_95581e8c14caf1b7963544079b2d014a_config['pid'] = plug_eva('epay_alipay_wxpay', 'pid');
$OSWAP_95581e8c14caf1b7963544079b2d014a_config['key'] = plug_eva('epay_alipay', 'key');
$OSWAP_95581e8c14caf1b7963544079b2d014a_config['sign_type'] = strtoupper('MD5');
$OSWAP_95581e8c14caf1b7963544079b2d014a_config['input_charset'] = strtolower('utf-8');

requirer('lib/epay_core.function.php', 'epay_alipay');
requirer('lib/epay_md5.function.php', 'epay_alipay');
requirer('lib/epay_notify.class.php', 'epay_alipay');

$OSWAP_95581e8c14caf1b7963544079b2d014a = new AlipayNotify($OSWAP_95581e8c14caf1b7963544079b2d014a_config);
$OSWAP_4dd416f16f17776af511a5637e5d5fabify_result = $OSWAP_95581e8c14caf1b7963544079b2d014a->verifyNotify();
if ($OSWAP_4dd416f16f17776af511a5637e5d5fabify_result) {
    $OSWAP_c672b944e3574a7c1fe7265d08a5e2eb = $_GET['trade_status'];
    $OSWAP_9be41f914bd69144aae3c257cfdcd0ce = $_GET['out_trade_no'];
    $OSWAP_5bcde255366557732432f59ea601e4d0 = $_GET['trade_no'];
    $OSWAP_e33c6362689d6c573ea7bc36541a3eda = $_GET['money'];
    $OSWAP_66d0ee9a393a5a0faceba57507977373 = 0;
    if ($OSWAP_c672b944e3574a7c1fe7265d08a5e2eb == 'TRADE_SUCCESS') {
        Pay::order_success($OSWAP_9be41f914bd69144aae3c257cfdcd0ce);
    }
    echo "success";
} else {
    echo "fail";
}